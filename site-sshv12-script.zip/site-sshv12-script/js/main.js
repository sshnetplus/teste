/* TOGGLE MENU */
  function toggleMenu() {
    var navMobile = document.getElementById("nav-mobile");
    var menuIcon = document.querySelector(".sidenav-trigger svg");
    var menuVisible = navMobile.classList.contains("show-sidenav");

    if (menuVisible) {
      navMobile.classList.remove("show-sidenav");
      menuIcon.innerHTML = '<path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z">';
    } else {
      navMobile.classList.add("show-sidenav");
      menuIcon.innerHTML = '<path d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>';
    }
  }




/* MODAL */
function openModal(modalId) {
  var modal = document.getElementById(modalId);
  modal.style.display = 'block';

  var closeButton = modal.querySelector('.modal-close');
  closeButton.addEventListener('click', closeModal);
}

function closeModal() {
    var modal = this.closest('.modal');
    modal.style.display = 'none';
}
/* TOGGLE COLLAPSE */
function toggleCollapse(header) {
  var body = header.nextElementSibling;
  body.style.display = body.style.display === 'block' ? 'none' : 'block';
}

/* TOGGLE PIX EMAIL */
function toggleCampoEmail(campoId) {
	var campoEmail = document.getElementById(campoId);
	campoEmail.style.display = campoEmail.style.display === 'none' ? 'block' : 'none';
}

/* HIDE ELEMENTS */
document.fonts.ready.then(function() {
  var icons = document.getElementsByClassName('material-icons');
  for (var i = 0; i < icons.length; i++) {
    icons[i].classList.remove('load-hide');
    icons[i].classList.add('loaded');
  }
});

  // Adicionar evento de clique a cada item do menu
  var menuItems = document.querySelectorAll("#nav-mobile li");
  menuItems.forEach(function(item) {
    item.addEventListener("click", function() {
      var navMobile = document.getElementById("nav-mobile");
      navMobile.classList.remove("show-sidenav");
      var menuIcon = document.querySelector(".sidenav-trigger i");
      menuIcon.innerHTML = "menu";
    });
  });

/* PLUGIN ESCASSEZ*/
  var r_text = [
	  "Lucas ",
	  "Júlia ",
	  "Mateus ",
	  "Francisco ",
	  "Letícia ",
	  "João ",
	  "Afonso ",
	  "Amanda ",
	  "Sandra ",
	  "Luiz ",
	  "Carlos ",
	  "Helena ",
	  "Adriana ",
	  "Jéssica ",
	  "Bruna ",
	  "Pedro ",
	  "José ",
	  "Camila ",
	  "Antônio ",
	  "Juliana ",
	  "Ana ",
	  "Guilherme ",
	  "Maria ",
	  "Beatriz ",
	  "Mariana ",
	  "Rafael ",
	  "Fernanda ",
	  "Leonardo ",
	  "Isabela ",
	  "Ricardo ",
	  "Vanessa ",
	  "Laura ",
	  "Gabriel ",
	  "Daniela ",
	  "Rodrigo ",
	  "Mariano ",
	  "Natália ",
	  "Fábio ",
	  "Larissa ",
	  "Gustavo ",
	  "Carolina ",
	  "Vinicius ",
	  "Rita ",
	  "Eduardo ",
	  "Bianca ",
	  "Fernando ",
	  "Carla ",
	  "Rafaela ",
	  "Diego ",
	  "Patrícia ",
	  "André ",
	  "Marina ",
	  "Rui ",
	  "Simone ",
	  "Alexandre ",
	  "Tatiana ",
	  "Raul ",
	  "Priscila ",
	  "Hugo ",
	  "Cristina ",
	  "Tiago ",
	  "Sara ",
	  "Daniel ",
	  "Paula ",
	  "Miguel ",
	  "Marta ",
	  "Ronaldo ",
	  "Rosa ",
	  "Filipe ",
	  "Vera ",
	  "Sofia ",
	  "Hélder ",
	  "Bárbara ",
	  "Noah ",
	  "Inês ",
	  "Simão ",
	  "Elsa ",
	  "Tomás ",
	  "Mónica ",
	  "David ",
	  "Cláudia ",
	  "Henrique ",
	  "Andreia ",
	  "Mário ",
	  "Patrícia ",
	  "Teresa ",
	  "Isabel ",
	  "Liliana ",
	  "Cátia ",
	  "Leandro ",
	  "Cristiana ",
	  "Emanuel ",
	  "Filipa ",
	  "Susana ",
	  "Bruno ",
	  "Rute ",
	  "Alex ",
	  "Sónia ",
	  "Jorge ",
	  "Célia ",
	  "Vítor ",
	  "Mafalda ",
	  "Nuno ",
	  "Vanessa ",
	  "Marco ",
	  "Carina ",
	  "Nelson ",
	  "Joana ",
	  "Paulo ",
	  "Manuel ",
	  "Lara ",
	  "Raquel "
	];

  var r_map = [
    "A.",
    "B.",
    "C.",
    "D.",
    "E.",
    "F.",
    "G.",
    "H.",
    "I.",
    "J.",
    "K.",
    "L.",
    "M.",
    "N.",
    "O.",
    "P.",
    "Q.",
    "R.",
    "S.",
    "T.",
    "U.",
    "V.",
    "Z.",
    "W."
  ];

  var r_product = [
    "Comprou com PIX",
    "Comprou com Cartão via Mercado Pago",
    "Comprou com Saldo do Mercado Pago",
    "Comprou com Cartão via PayPal",
    "Comprou com PIX",
    "Comprou com PIX",
    "Comprou com PIX",
    "Comprou com PIX",
    "Comprou com Cartão via Mercado Pago",
    "Comprou com Cartão via Mercado Pago"
  ];

function toggleCustomSocialProof() {
  var customSocialProof = document.querySelector(".custom-social-proof");
  if (customSocialProof.style.display === "none") {
    document.getElementById("map1").textContent = r_map[getRandomNumber(r_map.length)];
    document.getElementById("country").textContent = r_text[getRandomNumber(r_text.length)];
    document.getElementById("product").textContent = r_product[getRandomNumber(r_product.length)];
    var timeVal = getRandomNumber(28) + 1;
    document.getElementById("time").textContent = timeVal;

    customSocialProof.style.display = "block";
    setTimeout(function() {
      customSocialProof.style.display = "none";
    }, 4000); // Tempo de desaparecimento em 4 segundos
  }
}

function getRandomNumber(max) {
  return Math.floor(Math.random() * max);
}

var customSocialProof = document.querySelector(".custom-social-proof");
customSocialProof.style.display = "none"; // Adicionando estilo para ocultar inicialmente

var scrollTriggered = false; // Variável para controlar se a rolagem da página já foi acionada

window.addEventListener("scroll", function() {
  if (!scrollTriggered && (window.pageYOffset / (document.documentElement.scrollHeight - window.innerHeight)) >= 0.1) {
    scrollTriggered = true;
    toggleCustomSocialProof(); // Exibir o elemento quando a página for rolada até 10% da altura total
    setInterval(toggleCustomSocialProof, 10000); // Tempo de reaparecimento em 10 segundos
  }
});

/* PLACEHOLDER SKELETONS */
  window.addEventListener('load', function() {
    var placeholderElement = document.querySelector('.placeholder');
    placeholderElement.classList.remove('placeholder');
  });
